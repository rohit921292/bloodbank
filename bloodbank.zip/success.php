<?php 
include('includes/db_connect.php'); // Include database connection
?>

<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h2>Success</h2>

    <?php
    if (isset($_GET['message'])) {
        echo "<p style='color: green; font-weight: bold;'>" . htmlspecialchars($_GET['message']) . "</p>";
    }
    ?>

    <br><a href="index.html">Go to Home</a>
</body>
</html>
