<?php 
include('includes/db_connect.php'); // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Securely fetching user inputs
    $patient_name = htmlspecialchars($_POST['patient_name']);
    $blood_group = htmlspecialchars($_POST['blood_group']);
    $contact = htmlspecialchars($_POST['contact']);
    $hospital = htmlspecialchars($_POST['hospital']);

    // Debug: Check database connection
    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL statement (table: requests)
    $stmt = $conn->prepare("INSERT INTO requests (patient_name, blood_group, contact, hospital) VALUES (?, ?, ?, ?)");

    // Debug: Check if query preparation was successful
    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ssss", $patient_name, $blood_group, $contact, $hospital);

    // Execute statement
    if ($stmt->execute()) {
        // Redirect to success page after successful blood request
        header("Location: success.php?message=" . urlencode("Blood request submitted successfully!"));
        exit();
    } else {
        die("Execution failed: " . $stmt->error);
    }

    // Close statement
    $stmt->close();
}
?>
