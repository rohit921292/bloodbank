<?php 
include('includes/db_connect.php'); // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $blood_group = htmlspecialchars($_POST['blood_group']);
    $contact = htmlspecialchars($_POST['contact']);
    $city = htmlspecialchars($_POST['city']);

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO donors (name, blood_group, contact, city) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $blood_group, $contact, $city);

    if ($stmt->execute()) {
        // Redirect to success page with a success message for registration
        header("Location: success.php?message=Registration%20successful!");
        exit();
    } else {
        die("Error: " . $stmt->error);
    }

    $stmt->close();
}
?>
