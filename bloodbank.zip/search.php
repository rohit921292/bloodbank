<?php 
include('includes/db_connect.php'); // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $blood_group = htmlspecialchars($_POST['blood_group']);

    // Secure SQL query using prepared statements
    $stmt = $conn->prepare("SELECT name, contact, city FROM donors WHERE blood_group = ?");
    $stmt->bind_param("s", $blood_group);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>Donor: " . $row['name'] . " | Contact: " . $row['contact'] . " | City: " . $row['city'] . "</p>";
        }
    } else {
        // Redirect to success.php with a message for no donor found
        header("Location: success.php?message=No%20donors%20found%20for%20Blood%20Group:%20" . urlencode($blood_group));
        exit();
    }

    $stmt->close();
}
?>
