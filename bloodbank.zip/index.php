<?php
// Redirect to index.html
header("Location: index.html");
exit();
?>

<?php include('includes/db_connect.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Blood Bank Management</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h1>Welcome to Blood Bank Management System</h1>
    <a href="register.html"><button>Register as Donor</button></a>
    <a href="request_blood.html"><button>Request Blood</button></a>
    <a href="search.html"><button>Search Blood</button></a>
</body>
</html>
