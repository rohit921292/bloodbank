CREATE DATABASE IF NOT EXISTS bloodbank;
USE bloodbank;

CREATE TABLE donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    blood_group VARCHAR(10),
    contact VARCHAR(15),
    city VARCHAR(50),
    date_of_donation DATE DEFAULT CURRENT_DATE
);

CREATE TABLE requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(100),
    blood_group VARCHAR(10),
    hospital VARCHAR(100),
    contact VARCHAR(15),
    request_date DATE DEFAULT CURRENT_DATE
);
